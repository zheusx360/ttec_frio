module.exports = {
  apps : [{
    name   : "app1",
    script : "./src/pages/_app.tsx"
  }]
}
