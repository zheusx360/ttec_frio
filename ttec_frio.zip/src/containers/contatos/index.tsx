export function Contatos() {
  return (
    <div style={{display: 'flex', justifyContent:'center', alignItems:'center', width: '100%', height:'100vh', backgroundColor:'#6cb8b7'}}>
      <h1>Tela de Contatos</h1>
    </div>
  )
}
