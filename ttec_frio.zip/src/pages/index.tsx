import { Home } from "../containers/home";

export default Home;
