exports.id = 841;
exports.ids = [841];
exports.modules = {

/***/ 8093:
/***/ ((module) => {

// Exports
module.exports = {
	"html": "bt_html__JQLu_",
	"body": "bt_body__0cbgV",
	"h1": "bt_h1__WssrR",
	"p": "bt_p__CdOjt",
	"btn": "bt_btn__di9j6",
	"first": "bt_first__O7t7d",
	"second": "bt_second__oIDVv",
	"third": "bt_third__MpqCj",
	"fourth": "bt_fourth__hju8v",
	"fifth": "bt_fifth__JopzV",
	"sixth": "bt_sixth__ESDZI"
};


/***/ }),

/***/ 9841:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _bt_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8093);
/* harmony import */ var _bt_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_bt_module_scss__WEBPACK_IMPORTED_MODULE_1__);


function Button({ type =1 , text ="ACESSAR" , width =250 || 0 , heigth =58 || 0 , onClick =()=>{}  }) {
    let renderButton = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: (_bt_module_scss__WEBPACK_IMPORTED_MODULE_1___default().second),
        onClick: onClick,
        children: "Button 2"
    });
    switch(type){
        case 1:
            renderButton = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: (_bt_module_scss__WEBPACK_IMPORTED_MODULE_1___default().first),
                style: {
                    width: width,
                    height: heigth,
                    alignSelf: "center"
                },
                onClick: onClick,
                children: text
            });
            break;
        case 2:
            renderButton = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: (_bt_module_scss__WEBPACK_IMPORTED_MODULE_1___default().second),
                style: {
                    width: width,
                    height: heigth,
                    alignSelf: "center"
                },
                onClick: onClick,
                children: text
            });
            break;
        case 3:
            renderButton = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: (_bt_module_scss__WEBPACK_IMPORTED_MODULE_1___default().third),
                style: {
                    width: width,
                    height: heigth,
                    alignSelf: "center"
                },
                onClick: onClick,
                children: text
            });
            break;
        case 4:
            renderButton = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: (_bt_module_scss__WEBPACK_IMPORTED_MODULE_1___default().fourth),
                style: {
                    width: width,
                    height: heigth,
                    alignSelf: "center"
                },
                onClick: onClick,
                children: text
            });
            break;
        case 5:
            renderButton = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: (_bt_module_scss__WEBPACK_IMPORTED_MODULE_1___default().fifth),
                style: {
                    width: width,
                    height: heigth,
                    alignSelf: "center"
                },
                onClick: onClick,
                children: text
            });
            break;
        case 6:
            renderButton = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: (_bt_module_scss__WEBPACK_IMPORTED_MODULE_1___default().sixth),
                style: {
                    width: width,
                    height: heigth,
                    alignSelf: "center"
                },
                onClick: onClick,
                children: text
            });
            break;
    }
    return renderButton;
}


/***/ })

};
;