exports.id = 112;
exports.ids = [112];
exports.modules = {

/***/ 6887:
/***/ ((module) => {

// Exports
module.exports = {
	"menuMobile": "styles_menuMobile__pTAkU",
	"initalAnim": "styles_initalAnim__XdlDH",
	"headerContainer": "styles_headerContainer__UbNG_",
	"headerContainerB": "styles_headerContainerB__fmZ3g",
	"content": "styles_content__EBE8I",
	"icone": "styles_icone__piTie",
	"center": "styles_center__Gsd8H",
	"toggle": "styles_toggle__f_5Io",
	"closeButton": "styles_closeButton__ID9xQ",
	"Xanim": "styles_Xanim__Id66a"
};


/***/ }),

/***/ 6552:
/***/ ((module) => {

// Exports
module.exports = {
	"customImage": "carousel_customImage__lVi3y",
	"imageBack": "carousel_imageBack__tCs7K",
	"infoStyle": "carousel_infoStyle__wgIpE",
	"animation": "carousel_animation__g_tPg"
};


/***/ }),

/***/ 847:
/***/ ((module) => {

// Exports
module.exports = {
	"headerContainer": "styles_headerContainer__499M0",
	"headerContainerB": "styles_headerContainerB__gwArW",
	"headerContent": "styles_headerContent__fyXNz",
	"active": "styles_active__AHkhV",
	"readyButton": "styles_readyButton__ph77H"
};


/***/ }),

/***/ 4972:
/***/ ((module) => {

// Exports
module.exports = {
	"ul": "navbar_ul__VgJcH",
	"li": "navbar_li__0xD_0",
	"spring": "navbar_spring__Uv__S",
	"shameless-plug": "navbar_shameless-plug__h6m_S"
};


/***/ }),

/***/ 8112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "r5": () => (/* reexport */ Carossel),
  "h4": () => (/* reexport */ Header),
  "GP": () => (/* reexport */ HeaderMobile)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/header/styles.module.scss
var styles_module = __webpack_require__(847);
var styles_module_default = /*#__PURE__*/__webpack_require__.n(styles_module);
// EXTERNAL MODULE: ./src/components/navBarAnimated/navbar.module.scss
var navbar_module = __webpack_require__(4972);
var navbar_module_default = /*#__PURE__*/__webpack_require__.n(navbar_module);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
;// CONCATENATED MODULE: ./src/components/navBarAnimated/navbar.tsx



function NavbarAnimated({ marginLeft =5 , closeVisible  }) {
    const Navigation = (url)=>{
        setTimeout(()=>{
            closeVisible(true);
            router_default().push(url);
        }, 500);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            style: {
                marginLeft: marginLeft
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: (navbar_module_default()).ul,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: (navbar_module_default()).li,
                        onClick: ()=>Navigation("./")
                        ,
                        children: "Home"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: (navbar_module_default()).li,
                        onClick: ()=>Navigation("./orcamento")
                        ,
                        children: "Or\xe7amento"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: (navbar_module_default()).li,
                        onClick: ()=>Navigation("./servicos")
                        ,
                        children: "Servi\xe7os"
                    })
                ]
            })
        })
    });
}

;// CONCATENATED MODULE: ./src/components/header/index.tsx





function Header() {
    const { 0: theme , 1: setTheme  } = (0,external_react_.useState)(1);
    (0,external_react_.useEffect)(()=>{
        const handleScroll = ()=>{
            const show = window.scrollY > 100;
            if (show) {
                setTheme(2);
            } else {
                setTheme(1);
            }
        };
        document.addEventListener("scroll", handleScroll);
        return ()=>{
            document.removeEventListener("scroll", handleScroll);
        };
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("header", {
        id: "navbar",
        className: `${theme === 2 ? (styles_module_default()).headerContainerB : (styles_module_default()).headerContainer}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "nav-scrolled",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (styles_module_default()).headerContent,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            onClick: ()=>router_default().push("/")
                            ,
                            src: "/LogoMenu.svg",
                            width: 310,
                            alt: "TTECFRIO"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(NavbarAnimated, {
                            closeVisible: ()=>{},
                            marginLeft: 40
                        })
                    })
                ]
            })
        })
    });
}

// EXTERNAL MODULE: ./src/components/HeaderMobile/styles.module.scss
var HeaderMobile_styles_module = __webpack_require__(6887);
var HeaderMobile_styles_module_default = /*#__PURE__*/__webpack_require__.n(HeaderMobile_styles_module);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: ./src/components/HeaderMobile/index.tsx






function HeaderMobile() {
    const { 0: closeMenu , 1: setcloseMenu  } = (0,external_react_.useState)(true);
    const { 0: theme , 1: setTheme  } = (0,external_react_.useState)(1);
    (0,external_react_.useEffect)(()=>{
        const handleScroll = ()=>{
            const show = window.scrollY > 100;
            if (show) {
                setTheme(2);
            } else {
                setTheme(1);
            }
        };
        document.addEventListener("scroll", handleScroll);
        return ()=>{
            document.removeEventListener("scroll", handleScroll);
        };
    }, []);
    (0,external_react_.useEffect)(()=>{
        document.body.style.overflowY = !closeMenu ? "hidden" : "auto";
    }, [
        closeMenu
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (HeaderMobile_styles_module_default()).menuMobile,
                hidden: closeMenu,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        onClick: ()=>setcloseMenu(true)
                        ,
                        className: (HeaderMobile_styles_module_default()).closeButton,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsXLg, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(NavbarAnimated, {
                            closeVisible: setcloseMenu,
                            marginLeft: 40
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `${theme === 2 ? (HeaderMobile_styles_module_default()).headerContainerB : (HeaderMobile_styles_module_default()).headerContainer}`,
                hidden: !closeMenu,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (HeaderMobile_styles_module_default()).content,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_styles_module_default()).icone,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                onClick: ()=>router_default().push("/")
                                ,
                                src: "/IgluIcon.svg",
                                width: 60,
                                height: 55,
                                alt: "Icon"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_styles_module_default()).center,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                onClick: ()=>router_default().push("/")
                                ,
                                src: "/TitleLogo.svg",
                                width: 140,
                                height: 58,
                                alt: "Icon"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (HeaderMobile_styles_module_default()).toggle,
                            onClick: ()=>setcloseMenu(false)
                            ,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsJustifyRight, {})
                        })
                    ]
                })
            })
        ]
    });
}

// EXTERNAL MODULE: external "react-bootstrap/Carousel"
var Carousel_ = __webpack_require__(6964);
var Carousel_default = /*#__PURE__*/__webpack_require__.n(Carousel_);
// EXTERNAL MODULE: ./src/components/caroussel/carousel.module.scss
var carousel_module = __webpack_require__(6552);
var carousel_module_default = /*#__PURE__*/__webpack_require__.n(carousel_module);
;// CONCATENATED MODULE: ./src/components/caroussel/index.tsx






function Carossel() {
    const { 0: theme , 1: setTheme  } = (0,external_react_.useState)("");
    const { 0: indice , 1: setIndice  } = (0,external_react_.useState)(true);
    const nextIcon = /*#__PURE__*/ jsx_runtime_.jsx("span", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillArrowRightCircleFill, {})
        })
    });
    const prevIcon = /*#__PURE__*/ jsx_runtime_.jsx("span", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
            children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsFillArrowLeftCircleFill, {})
        })
    });
    (0,external_react_.useEffect)(()=>{
        setIndice(!indice);
        ResetValues();
    }, []);
    const ResetValues = ()=>{
        let i = !indice;
        setIndice(i);
        setTimeout(()=>{
            if (i) {
                setTheme((carousel_module_default()).customImage);
            } else {
                setTheme((carousel_module_default()).imageBack);
            }
        }, 190);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Carousel_default()), {
            fade: true,
            interval: 8000,
            nextIcon: nextIcon,
            prevIcon: prevIcon,
            pause: false,
            indicators: false,
            onSelect: ()=>ResetValues()
            ,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Carousel_default()).Item, {
                    className: theme,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "unset-img full-bleed",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                style: {
                                    width: "100%",
                                    height: "100vh"
                                },
                                src: "/images/ImagesCarousel/freezer1.jpg",
                                alt: "First slide"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Carousel_default()).Caption, {
                            className: (carousel_module_default()).infoStyle,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "C\xe2maras frigorificas"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "N\xe3o sofra com problemas causados por falta de manute\xe7\xe3o"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Carousel_default()).Item, {
                    className: theme,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "unset-img full-bleed",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                style: {
                                    width: "100%",
                                    height: "100vh"
                                },
                                src: "/images/ImagesCarousel/freezer2.jpg",
                                alt: "Second slide"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Carousel_default()).Caption, {
                            className: (carousel_module_default()).infoStyle,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Atendimento em toda grande S\xe3o Paulo"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Atendimento personalizado e com garantia de satisfa\xe7\xe3o."
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Carousel_default()).Item, {
                    className: theme,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "unset-img full-bleed",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                style: {
                                    width: "100%",
                                    height: "100vh"
                                },
                                src: "/images/ImagesCarousel/freezer3.jpg",
                                alt: "Second slide"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Carousel_default()).Caption, {
                            className: (carousel_module_default()).infoStyle,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "A quase 10 anos no mercado"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Confie em quem tem experi\xeancia no mercado e sempre oferece o melhor para seus clientes."
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Carousel_default()).Item, {
                    className: theme,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "unset-img full-bleed",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                style: {
                                    width: "100%",
                                    height: "100vh"
                                },
                                src: "/images/ImagesCarousel/clientes.jpg",
                                alt: "Second slide"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Carousel_default()).Caption, {
                            className: (carousel_module_default()).infoStyle,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Clientes 100% satisfeito e felizes"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Uma equipe a disposi\xe7\xe3o sempre que seu neg\xf3cio precisar de um socorro."
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./src/components/index.tsx






/***/ })

};
;