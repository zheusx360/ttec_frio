(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 3690:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "home_section__HNb7c",
	"content": "home_content__RKnyl",
	"contentText": "home_contentText__Ey3kf",
	"row": "home_row__MMM9L",
	"row2": "home_row2__Kp6PH",
	"column": "home_column__oqS6R",
	"sectionContainer": "home_sectionContainer__Yi_R4",
	"sectionTop": "home_sectionTop__Py5lm",
	"sectionSub": "home_sectionSub__72p04",
	"imageSection": "home_imageSection__6MCwK",
	"imageText": "home_imageText__uH1Cg"
};


/***/ }),

/***/ 4026:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/index.tsx + 4 modules
var components = __webpack_require__(8112);
// EXTERNAL MODULE: ./src/containers/home/home.module.scss
var home_module = __webpack_require__(3690);
var home_module_default = /*#__PURE__*/__webpack_require__.n(home_module);
// EXTERNAL MODULE: ./src/components/buttons/animatedButton/index.tsx
var animatedButton = __webpack_require__(9841);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
;// CONCATENATED MODULE: ./src/containers/home/index.tsx





function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Carossel */.r5, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (home_module_default()).section,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (home_module_default()).column,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (home_module_default()).row,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (home_module_default()).content,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/images/ImagesCarousel/satisfacao.jpg",
                                        alt: "Satisfa\xe7\xe3o",
                                        width: 400,
                                        height: 350
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (home_module_default()).contentText,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Excel\xeancia no Atendimento"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "A ttec frio tem como uma de suas maiores prioridades a excel\xeancia no atendimento e esse \xe9 um dos motivos para sua perman\xeancia por mais de duas d\xe9cadas no mercado."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u2022 Atendimento extremamente r\xe1pido"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u2022 Equipe especializada"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u2022 Pre\xe7os abaixo do mercado"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u2022 Suporte t\xe9cnico 24 horas"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (home_module_default()).row2,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (home_module_default()).contentText,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Equipe t\xe9cnica especializada"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Contamos com uma equipe altamente especializada, estamos sempre buscando o que existe de melhor e mais t\xe9cnologico no mercado, para oferecer sempre um servi\xe7o de ponta e atualizado."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u2022 Equipe altamente treinada"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u2022 T\xe9cnologia de ponta"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "\u2022 Equipamentos modernos"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (home_module_default()).content,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/images/ImagesCarousel/freezer6.jpg",
                                        alt: "T\xe9cnologia",
                                        width: 400,
                                        height: 350
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (home_module_default()).sectionContainer,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("section", {
                        className: (home_module_default()).sectionTop,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (home_module_default()).imageSection,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/images/ImagesCarousel/qualidade.jpg",
                                        alt: "Eficiencia",
                                        width: 420,
                                        height: 350
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (home_module_default()).imageText,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            children: "Qualidade e agilidade"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    "Estamos preparados com o que h\xe1 de melhor no mercado para entregar o servi\xe7o desejado com muita qualidade e agilidade, garantindo assim a melhor entrega no menor prazo. solicite um or\xe7amento e se surpreenda com o que temos para te oferecer.",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(animatedButton/* Button */.z, {
                                                            type: 5,
                                                            text: "SOLICITAR OR\xc7AMENTO",
                                                            onClick: ()=>router_default().push("/orcamento")
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("section", {
                        className: (home_module_default()).sectionSub
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/pages/index.tsx

/* harmony default export */ const pages = (Home);
const getStaticProps = async ()=>{
    return {
        props: {},
        revalidate: 60 * 30
    };
};


/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6964:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap/Carousel");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [112,841], () => (__webpack_exec__(4026)));
module.exports = __webpack_exports__;

})();