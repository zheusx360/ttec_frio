(() => {
var exports = {};
exports.id = 264;
exports.ids = [264];
exports.modules = {

/***/ 9929:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "servicos_container___MmN7",
	"titulo": "servicos_titulo__ksW3J",
	"content": "servicos_content__H7ukM",
	"circle": "servicos_circle__TNEQ1",
	"iconContent": "servicos_iconContent__Eq5wP",
	"square": "servicos_square__W_R_d"
};


/***/ }),

/***/ 9305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ servicos),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/IconsAnimated/index.tsx + 3 modules
var IconsAnimated = __webpack_require__(7242);
// EXTERNAL MODULE: ./src/containers/servicos/servicos.module.scss
var servicos_module = __webpack_require__(9929);
var servicos_module_default = /*#__PURE__*/__webpack_require__.n(servicos_module);
;// CONCATENATED MODULE: ./src/containers/servicos/index.tsx



function Servicos() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (servicos_module_default()).container,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (servicos_module_default()).iconContent,
                children: /*#__PURE__*/ jsx_runtime_.jsx(IconsAnimated/* default */.Z, {
                    imagem: "certificado",
                    loop: false
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (servicos_module_default()).titulo,
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: "NOSSOS SERVI\xc7OS"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (servicos_module_default()).content,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (servicos_module_default()).circle,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/images/ImagesCarousel/freezer4.jpg",
                            alt: "Satisfa\xe7\xe3o",
                            width: 500,
                            height: 500
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (servicos_module_default()).square,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Manutencao de c\xe2maras frias"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "A manuten\xe7\xe3o preventiva c\xe2maras frigor\xedficas oferece uma s\xe9rie de vantagens, entre elas: garantir a caracter\xedstica dos produtos armazenados. Pois uma quebra ou falha no funcionamento do sistema pode danificar e at\xe9 impossibilitar o uso ou venda dos produtos, gerando grandes peju\xedzos em sua receita."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (servicos_module_default()).content,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (servicos_module_default()).circle,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/images/ImagesCarousel/monitorar.jpg",
                            alt: "Satisfa\xe7\xe3o",
                            width: 500,
                            height: 500
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (servicos_module_default()).square,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Sitema de alarmes"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "A seguran\xe7a de seus equipamentos \xe9 fundamental, com isso \xe9 imprescind\xedvel ter uma seguran\xe7a mesmo quando sua empresa est\xe1 fechada. Fazemos instala\xe7\xe3o de alarmes que monitoram 24 horas seus equipamentos, dando a seguran\xe7a de que tudo estar\xe1 100% funcional 24 horas por dia."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (servicos_module_default()).content,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (servicos_module_default()).circle,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/images/ImagesCarousel/freezer3.jpg",
                            alt: "Satisfa\xe7\xe3o",
                            width: 500,
                            height: 500
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (servicos_module_default()).square,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Montagem e desmontagem de c\xe2maras frias"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Somos especializados em montagem e desmontagem de c\xe2maras frias, seja para um pequeno, m\xe9dio ou grande neg\xf3cio n\xf3s temos a solu\xe7\xe3o necess\xe1ria para atender a demanda que voc\xea precisa, com a ttec frio voc\xea tem a garantia de instala\xe7\xe3o ou desmontagem com 100% de efici\xeancia."
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/pages/servicos.tsx

/* harmony default export */ const servicos = (Servicos);
const getStaticProps = async ()=>{
    return {
        props: {},
        revalidate: 60 * 30
    };
};


/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 1189:
/***/ ((module) => {

"use strict";
module.exports = require("react-lottie");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [242], () => (__webpack_exec__(9305)));
module.exports = __webpack_exports__;

})();