(() => {
var exports = {};
exports.id = 547;
exports.ids = [547];
exports.modules = {

/***/ 2073:
/***/ ((module) => {

// Exports
module.exports = {
	"inputContainer": "input_inputContainer__JmMRY",
	"label": "input_label__qBRrc",
	"textInput": "input_textInput__k7TF0"
};


/***/ }),

/***/ 7745:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "servicos_container__oK2ib",
	"leftContent": "servicos_leftContent__dKR8L",
	"iconContent": "servicos_iconContent__s6ggg",
	"rightContent": "servicos_rightContent__snheq",
	"buttons": "servicos_buttons__oaWMK",
	"icon": "servicos_icon__ThU9d",
	"message": "servicos_message__pqAGy",
	"btMessage": "servicos_btMessage__90th1"
};


/***/ }),

/***/ 3457:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ orcamento),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/containers/orcamento/servicos.module.scss
var servicos_module = __webpack_require__(7745);
var servicos_module_default = /*#__PURE__*/__webpack_require__.n(servicos_module);
// EXTERNAL MODULE: ./src/components/input/input.module.scss
var input_module = __webpack_require__(2073);
var input_module_default = /*#__PURE__*/__webpack_require__.n(input_module);
;// CONCATENATED MODULE: ./src/components/input/maskTel.tsx
const MaskTel = (v)=>{
    let r = v.replace(/\D/g, "");
    r = r.replace(/^0/, "");
    if (r.length > 11) {
        r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
    } else if (r.length > 7) {
        r = r.replace(/^(\d\d)(\d{5})(\d{0,4}).*/, "($1) $2-$3");
    } else if (r.length > 2) {
        r = r.replace(/^(\d\d)(\d{0,5})/, "($1) $2");
    } else if (v.trim() !== "") {
        r = r.replace(/^(\d*)/, "($1");
    }
    return r;
};

;// CONCATENATED MODULE: ./src/components/input/index.tsx




function Input({ placeholder ="Digite seu nome." , name ="Nome" , width =250 || 0 , multiline =false , height =multiline ? 100 || 0 : 51 || 0 , marginTop = false || "0" , maxLength =multiline ? 200 : 30 , marginBottom = false || "0" , marginRight = false || "0" , marginLeft = false || "0" , type ="text" , onChange  }) {
    const { 0: value , 1: setValue  } = (0,external_react_.useState)("");
    const setValueInput = (arg)=>{
        if (type === "tel") {
            const tel = MaskTel(arg);
            setValue(tel);
            onChange(tel);
        } else {
            setValue(arg);
            onChange(arg);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        style: {
            width: width,
            height: height,
            marginTop: marginTop,
            marginBottom: marginBottom,
            marginLeft: marginLeft,
            marginRight: marginRight
        },
        className: (input_module_default()).inputContainer,
        children: [
            !multiline ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "text",
                id: "username",
                maxLength: maxLength,
                autoComplete: "off",
                placeholder: placeholder,
                className: (input_module_default()).textInput,
                value: value,
                onChange: (e)=>setValueInput(e.target.value)
            }) : /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                style: {
                    resize: "none"
                },
                maxLength: maxLength,
                id: "username",
                autoComplete: "off",
                placeholder: placeholder,
                className: (input_module_default()).textInput,
                value: value,
                onChange: (e)=>setValueInput(e.target.value)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                className: (input_module_default()).label,
                children: name
            })
        ]
    });
};

// EXTERNAL MODULE: ./src/components/buttons/animatedButton/index.tsx
var animatedButton = __webpack_require__(9841);
;// CONCATENATED MODULE: external "dayjs"
const external_dayjs_namespaceObject = require("dayjs");
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_namespaceObject);
// EXTERNAL MODULE: ./src/components/IconsAnimated/index.tsx + 3 modules
var IconsAnimated = __webpack_require__(7242);
;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_namespaceObject);
;// CONCATENATED MODULE: ./src/utils/baseUrl.js

const api = external_axios_default().create({
    baseURL: "https://api-control-base.herokuapp.com/user-system"
});
/* harmony default export */ const baseUrl = (api);

;// CONCATENATED MODULE: ./src/containers/orcamento/index.tsx








function Orcamento() {
    const { 0: nome , 1: setName  } = (0,external_react_.useState)("");
    const { 0: fone , 1: setFone  } = (0,external_react_.useState)("");
    const { 0: email , 1: setEmail  } = (0,external_react_.useState)("");
    const { 0: text , 1: setText  } = (0,external_react_.useState)("");
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const { 0: sucesso , 1: setSucesso  } = (0,external_react_.useState)(false);
    const { 0: txtSend , 1: setTxtSend  } = (0,external_react_.useState)("");
    let data = `Data: ${external_dayjs_default()().format("DD/MM/YYYY")} Hora: ${external_dayjs_default()().format("HH:MM")}`;
    const verificaCampos = ()=>{
        if (!nome || fone.length < 13 || !email || !text) {
            alert(`Os seguintes campos devem ser verificados:

      ${!nome ? "Nome" : ""}
      ${fone.length < 15 ? "Telefone" : ""}
      ${!email ? "Email" : ""}
      ${!text ? "Resumo" : ""}
      `);
            return;
        } else {
            return true;
        }
    };
    const Sucess = ()=>{
        setSucesso(false);
        setName("");
        setEmail("");
        setFone("");
        setText("");
    };
    const sendEmail = ()=>{
        if (verificaCampos()) {
            setLoading(true);
            baseUrl.post("/ttecSend", {
                nome,
                fone,
                email,
                text,
                data
            }).then((response)=>{
                setLoading(false);
                setTxtSend("Email enviado com sucesso! Aguarde nosso contato.");
                setSucesso(true);
            }).catch((error)=>{
                setLoading(false);
                console.log(error);
                setTxtSend("Erro ao enviar o email!");
                setSucesso(true);
            });
            Sucess();
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (servicos_module_default()).container,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (servicos_module_default()).leftContent,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (servicos_module_default()).iconContent,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/IconIgluCircle.svg",
                            alt: "Logo"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "SOLICITE UM OR\xc7AMENTO CONOSCO"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Preencha os dados do formul\xe1rio e receba um super desconto em nossos servi\xe7os para sua casa ou empresa, com a TTEC FRIO voc\xea sempre ganha!"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (servicos_module_default()).rightContent,
                children: sucesso ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (servicos_module_default()).message,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: txtSend
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(animatedButton/* Button */.z, {
                            type: 4,
                            width: "60%",
                            text: "OK",
                            onClick: ()=>Sucess()
                        })
                    ]
                }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                    children: loading ? /*#__PURE__*/ jsx_runtime_.jsx(IconsAnimated/* default */.Z, {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (servicos_module_default()).icon,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(IconsAnimated/* default */.Z, {
                                    width: "100%",
                                    height: "100%",
                                    imagem: "formulario",
                                    loop: false
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "PREENCHA OS DADOS PARA SOLICITAR SEU OR\xc7AMENTO"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (servicos_module_default()).buttons,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                                    width: 350,
                                    onChange: setName
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (servicos_module_default()).buttons,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                                    type: "tel",
                                    placeholder: "Digite seu telefone",
                                    name: "Telefone",
                                    width: 350,
                                    onChange: setFone
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (servicos_module_default()).buttons,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                                    placeholder: "Insira seu e-mail",
                                    name: "Email",
                                    width: 350,
                                    onChange: setEmail
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (servicos_module_default()).buttons,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Input, {
                                    multiline: true,
                                    height: 130,
                                    placeholder: "Do que voc\xea precisa?.",
                                    name: "Resumo",
                                    width: 350,
                                    onChange: setText
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(animatedButton/* Button */.z, {
                                type: 5,
                                text: "SOLICITAR OR\xc7AMENTO",
                                onClick: sendEmail
                            })
                        ]
                    })
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./src/pages/orcamento.tsx

/* harmony default export */ const orcamento = (Orcamento);
const getStaticProps = async ()=>{
    return {
        props: {},
        revalidate: 60 * 30
    };
};


/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 1189:
/***/ ((module) => {

"use strict";
module.exports = require("react-lottie");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [242,841], () => (__webpack_exec__(3457)));
module.exports = __webpack_exports__;

})();