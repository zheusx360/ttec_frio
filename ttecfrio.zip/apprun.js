module.exports =
{
  "apps": [
      {
          "name": "ttecfrio",
          "script": "npm",
          "args" : "start"
      }
  ]
}
